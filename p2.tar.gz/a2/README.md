# CSC 360 Assignment 2

A simple multi-threaded task scheduler made using C. The program simulates an airline check-in system (ACS) which has 2 queues (business and economy) and 4 clerks to serve customers in the queues. Customers are loaded in through an input file passed as an argument and the clerks service them appropriately.

## Compiling Instructions

1. Navigate to the directory for the program
2. Type "make ACS" in the command line to compile
3. Type "./ACS <inputfile>" to run
